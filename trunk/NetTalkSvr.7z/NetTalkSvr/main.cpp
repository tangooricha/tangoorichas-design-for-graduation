#include <windows.h>
#include <stdio.h>
#include <winsock2.h>
#include <conio.h>


int clientCounter=0
struct ChldThrdPara
{
	int clientNumber;
};

/*void ChildThread()
{
	char tmpBuffer[65536]

	recv(client,tmpBuffer,65536,0);
}*/

main()
{
	WSADATA wsaData;

	SOCKET server,client[8];
	sockaddr_in serverAddr,clientAddr[8];

	clinetAddrLenth=sizeof(clientAddr[0]);

	/*if(WSAStertup(MAKEWORD(1,1),&wsaData)!=0)
	{
		return 0;
	}

	serverAddr.sin_family=AF_INET;
	serverAddr.sin_addr.S_un=INADDR_ANY;
	serverAddr.sin_port=htons(4000);

	if((server=socket(AF_INET,SOCK_STREAM,0))=INVALID_SOCKET)
	{
		return 0;
	}
	
	if(bind(server,(sockaddr*)&serverAddr,sizeof(serverAddr))!=0)
	{
		return 0;
	}

	if(listen(server,10)!=0)
	{
		return 0;
	}

	while(ture)
	{
		client[clientCounter]=accept(server,(sockaddr*)clientAddr[clientCounter],&clinetAddrLenth);
		ChldThrdPara->clientNumber=clientCounter;
		HANDLE hThread=CreateThread(NULL,0,ChildThread,(LPVOID)ChldThrdPara,0,NULL);
		CloseHandle(hThread);
	}*/
}